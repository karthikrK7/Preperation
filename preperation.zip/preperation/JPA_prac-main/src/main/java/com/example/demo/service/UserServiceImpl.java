package com.example.demo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.Address;
import com.example.demo.entity.User;
import com.example.demo.repository.UserRepository;

@Service("UserServiceImpl")
public class UserServiceImpl implements UserService{

	@Autowired
	UserRepository userRepo;
	
	@Override
	public User saveUser(User user) {
		Address add = user.getAddress();
		user.setAddress(add);
		user = userRepo.save(user);
		return user;
	}

	@Override
	public User findByUserd(int userId) {
		User user = userRepo.findByUserId(userId);
		return user;
	}

}
