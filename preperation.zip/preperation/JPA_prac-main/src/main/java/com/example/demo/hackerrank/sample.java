package com.example.demo.hackerrank;

public class sample {

}
