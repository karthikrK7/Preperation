package com.example.demo.controller;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

@FeignClient(name="test-service")
public interface BookRestConsumer {

	@RequestMapping(value = "test-service/test/hey",method = RequestMethod.GET)
    @ResponseBody
    public String helloworld();

}