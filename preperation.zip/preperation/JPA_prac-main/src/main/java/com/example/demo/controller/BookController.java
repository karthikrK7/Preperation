package com.example.demo.controller;

import java.util.HashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.Book;
import com.example.demo.service.BookService;


@RestController
@RequestMapping("/resource-service/book")
public class BookController {
	
	@Autowired
	private BookService bookService;
	
	@Autowired
    private BookRestConsumer consumer;
	
	
	
	@RequestMapping(value = "/savebook",method = RequestMethod.POST)
	@ResponseBody
    public Book saveBook(@RequestBody Book book) {
		Book bookResponse = bookService.saveBook(book);
		return bookResponse;
	}
	
	@RequestMapping(value = "/testbook",method = RequestMethod.POST)
	@ResponseBody
    public Book testBook(@ModelAttribute(value = "book") Book book,ModelMap map) {
		map.addAttribute("bookName", "spaceX");
		System.out.println(book.toString());
		Book bookResponse = bookService.saveBook(book);
		return bookResponse;
	}
	
	
	@RequestMapping(value = "/{bookId}",method = RequestMethod.GET,produces ="application/json")
    @ResponseBody
    public Book getBookDetails(@PathVariable int bookId) {
		Book bookResponse = bookService.findByBookId(bookId);
		
		return bookResponse;
	}
	
	@RequestMapping(value = "/hello",method = RequestMethod.GET)
    @ResponseBody
    public String sayhello() {
		String result = consumer.helloworld();
		if(result!=null) {
			return result;
		}
		return "Hello World from book-service";
	}
	
	    public int[] twoSum(int[] nums, int target) {
	        int n = nums.length;
	        HashMap<Integer,Integer> map = new HashMap<Integer,Integer>();
	        int[] ans = new int[2];
	        for(int i=0;i<n;i++){
	            int temp = target - nums[i];
	            
	            if(map.containsKey(temp)){
	                ans[0]=map.get(temp);
	                ans[1]=i;
	                break;
	            }
	            map.put(nums[i],i);
	        }
	        return ans;
	    }
	    
	    public int maxSubArray(int[] nums) {
	        int max = nums[0];
	        for(int i=1;i<nums.length;i++){
	            if(nums[i-1]>0){
	                nums[i]+= nums[i-1];
	            }
	            max = Math.max(max,nums[i]); 
	        }
	        
	        return max;
	    }
	    public static void main(String[] args) {
	    	BookController b = new BookController();
	    	int [] a ={2,15,11,7};
	    	b.twoSum(a, 9);
	    	int [] nums = {-2,1,-3,4,-1,2,1,-5,4};
	    	b.maxSubArray(nums);
		}
}