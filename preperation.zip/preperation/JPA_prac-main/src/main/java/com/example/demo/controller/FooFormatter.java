package com.example.demo.controller;

import org.springframework.stereotype.Component;

import com.example.demo.service.Formatter;

@Component("fooFormatter")
public class FooFormatter implements Formatter {
    public String format() {
        return "foo";
    }
}
