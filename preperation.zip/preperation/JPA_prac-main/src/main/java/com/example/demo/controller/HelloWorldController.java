package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.User;
import com.example.demo.service.FooService;
import com.example.demo.service.UserService;

@RestController
@RequestMapping(value="/user")
public class HelloWorldController {

	@Autowired
	private UserService userService;
	
	@Autowired
	private FooService fooservice;

	@RequestMapping(value = "/saveuser", method = RequestMethod.POST, produces = "application/json")
	@ResponseBody
	public User saveUSer(@RequestBody User user) {
		user = userService.saveUser(user);
		return user;
	}

	@RequestMapping(value = "/{userId}", method = RequestMethod.GET, produces = "application/json")
	@ResponseBody
	public User getUser(@PathVariable int userId) {
		User usr = userService.findByUserd(userId);
		return usr;
	}

	
	@RequestMapping(value = "/format", method = RequestMethod.GET, produces = "application/json")
	@ResponseBody
	public String getFormat() {
		fooservice.method1();
		return null;
	}
	

}
