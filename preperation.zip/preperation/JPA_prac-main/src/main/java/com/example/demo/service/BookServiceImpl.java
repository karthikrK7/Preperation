package com.example.demo.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.Book;
import com.example.demo.entity.Story;
import com.example.demo.repository.BookRepository;

@Service("bookServiceImpl")
public class BookServiceImpl implements BookService {

	@Autowired
	private BookRepository bookRepository;

	public Book saveBook(Book book) {
//		List<Book> bb = new ArrayList();
//		Book bak = new Book();
//		bak.setBookName("saran");
//		bak.set
		book = bookRepository.save(book);
		return book;

	}

	public Book findByBookId(int bookId) {
		Book book = bookRepository.findByBookId(bookId);
		return book;
	}
}