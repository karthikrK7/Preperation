package com.example.demo.controller;

import org.springframework.stereotype.Component;

import com.example.demo.service.Formatter;

@Component("barFormatter")
public class BarFormatter implements Formatter {
    public String format() {
        return "bar";
    }
}