package com.example.demo.hackerrank;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Scanner;

@Word2PDF(method = "")
public class Programs {
	
	public void method() {
		
	}

	public static void main(String[] args) throws Exception {
		System.out.println(Programs.class.getMethods()[0].getName());
		System.out.println(Class.forName("com.example.demo.hackerrank.Word2PDF").getDeclaredMethods()[0].getName());
		try {
			if(Class.forName("com.example.demo.hackerrank.Word2PDF").getDeclaredMethods()[0].getName()!=Programs.class.getMethods()[1].getName()) {
				throw new Exception("method not implemented");
			}
		} catch (SecurityException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (ClassNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		try {
			System.out.println(Class.forName("com.example.demo.hackerrank.Word2PDF").getDeclaredMethods()[0]);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// TODO Auto-generated method stub
//		Scanner in = new Scanner(System.in);
//		int testCases = Integer.parseInt(in.nextLine());
//
//		List<Student> studentList = new ArrayList<Student>();
//		while (testCases > 0) {
//			int id = in.nextInt();
//			String fname = in.next();
//			double cgpa = in.nextDouble();
//
//			Student st = new Student(id, fname, cgpa);
//			studentList.add(st);
//
//			testCases--;
//		}
//		studentList.sort(Comparator.comparingDouble(Student::getCgpa).reversed().thenComparing(Student::getFname));
//		for (Student st : studentList) {
//			System.out.println(st.getFname());
//		}
	}

}

class Student {
	private int id;
	private String fname;
	private double cgpa;

	public Student(int id, String fname, double cgpa) {
		super();
		this.id = id;
		this.fname = fname;
		this.cgpa = cgpa;
	}

	public int getId() {
		return id;
	}

	public String getFname() {
		return fname;
	}

	public double getCgpa() {
		return cgpa;
	}
}
