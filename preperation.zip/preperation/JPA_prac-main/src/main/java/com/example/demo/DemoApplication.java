package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.cloud.openfeign.EnableFeignClients;

@SpringBootApplication
@EnableDiscoveryClient
@EnableFeignClients
@RefreshScope
public class DemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoApplication.class, args);
		
	}
	
//	public static void main(String[] args) {
//        ApplicationContext context = 
//                  new ClassPathXmlApplicationContext(new String[] {"com/example/demo/appConfig.xml"});
//          
//                EmployeeBean employee = (EmployeeBean)context.getBean("employee");
// 
//                System.out.println(employee.getFullName());
// 
//                System.out.println(employee.getDepartmentBean().getName());
//    }

}
