package com.example.demo.service;

public interface Formatter {
	 public String format();
}
