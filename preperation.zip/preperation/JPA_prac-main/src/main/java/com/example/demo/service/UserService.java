package com.example.demo.service;

import org.springframework.stereotype.Component;

import com.example.demo.entity.User;

@Component
public interface UserService {
	

	public User saveUser(User user);
	public User findByUserd(int userId);

}
