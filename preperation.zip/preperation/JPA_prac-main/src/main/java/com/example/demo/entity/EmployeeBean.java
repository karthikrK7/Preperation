package com.example.demo.entity;

import org.springframework.beans.factory.annotation.Autowired;

public class EmployeeBean
{
	
//	@Autowired
//	public EmployeeBean(DepartmentBean departmentName) {
//		this.departmentName = departmentName;
//	}
	
//	@Autowired
    private DepartmentBean departmentName;
     
    private String fullName;
 
    public DepartmentBean getDepartmentBean() {
        return departmentName;
    }
    @Autowired
    public void setDepartmentBean(DepartmentBean departmentName) {
        this.departmentName = departmentName;
    }
    public String getFullName() {
        return fullName;
    }
    public void setFullName(String fullName) {
        this.fullName = fullName;
    }
}